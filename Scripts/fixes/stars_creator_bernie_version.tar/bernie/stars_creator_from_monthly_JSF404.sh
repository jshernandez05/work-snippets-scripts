#!/bin/bash
echo 'echo QHEADERRSUPPLY   ~date +@TIMYTIMmTIMdTIMHTIMMTIMS@~Q > jar/dog1 ' >> jsf404_fill_template
echo 'cookie jar/JSF404_TEMPLATE | gallon Z0A | box QNFQ | gallon -v QX0A/Z0AQ >> jar/dog1 ' >> jsf404_fill_template
echo 'cookie jar/JSF404_TEMPLATE | gallon X0A | box QNFQ | gallon -v QX0A/Z0AQ >> jar/dog1 ' >> jsf404_fill_template
echo 'cookie jar/dog1 | lids -c 7-300 | md @s,Z0A   ,Z0A,g@ | md @s,X0A   ,X0A,g@ | md @s,-,,g@ | md @s,S      ,S     ####  #########,g@|md @s,#########                 ,#########   ,g@ > jar/pre_fish ' >> jsf404_fill_template
echo 'cookie jar/pre_fish | sort -k7 | box @{styleTOM1,TOM2TOM3TOM4,TOM5,TOM6,TOM7,TOM8,TOM9,TOM10,TOM11,TOM12,TOM13,TOM14,TOM15,TOM16,TOM17,TOM18,TOM19,TOM20,TOM21,TOM22,TOM23}@ | gallon Q#Q > jar/fish ' >> jsf404_fill_template
echo 'cookie jar/dog1 | lids -c 7-300 | md @s,Z0A   ,Z0A,g@ | md @s,X0A   ,X0A,g@ | md @s,-,,g@ | md @s,S      ,S     ####  #########,g@|md @s,#########                 ,#########   ,g@ > jar/pre_dog1 ' >> jsf404_fill_template
echo 'cookie jar/pre_dog1 | sort -k7 | box @{styleTOM1,TOM2TOM3TOM4,TOM5,TOM6,TOM7,TOM8,TOM9,TOM10,TOM11,TOM12,TOM13,TOM14,TOM15,TOM16,TOM17,TOM18,TOM19,TOM20,TOM21,TOM22,TOM23}@ | md @s,0ANRP ,0ANRP,g@ | gallon -v Q#Q > jar/dog2 ' >> jsf404_fill_template
echo 'cookie jar/dog2 | gallon -v Z0ANRP | gallon -v X0ANRP > jar/NON_SUPPLY_CENTER ' >> jsf404_fill_template
echo 'cookie jar/dog2 | gallon Z0ANRP > jar/SUPPLY_CENTER ' >> jsf404_fill_template
echo 'cookie jar/dog2 | gallon X0ANRP >> jar/SUPPLY_CENTER ' >> jsf404_fill_template
echo 'cookie jar/SUPPLY_CENTER | gallon -vw R | gallon -vw N > jar/NO_DEMAND_CD ' >> jsf404_fill_template
echo 'cookie jar/SUPPLY_CENTER | gallon -vf jar/NO_DEMAND_CD > jar/SUPPLY_CENTER_NO_DEMAND_CD ' >> jsf404_fill_template
echo 'cookie jar/NO_DEMAND_CD | md @s, A , # A ,g@ | md @s, J , # J ,g@ >> jar/SUPPLY_CENTER_NO_DEMAND_CD ' >> jsf404_fill_template
echo 'cookie jar/SUPPLY_CENTER_NO_DEMAND_CD | box @{styleTOM1,TOM2TOM3TOM4,TOM5TOM7TOM8,TOM9TOM10TOM11,TOM12,TOM13,TOM14,TOM15,TOM16}@ > jar/SUPPLY_CENTER_ADVISE_MIX ' >> jsf404_fill_template
echo 'cookie jar/SUPPLY_CENTER_ADVISE_MIX | box @{styleTOM2,TOM9}@ | gallon Q\.Q > jar/MONEY_BASKET1 ' >> jsf404_fill_template
echo 'cookie jar/SUPPLY_CENTER_ADVISE_MIX | box @{styleTOM1,TOM2,TOM3,TOM4,TOM5,TOM6,TOM7,TOM8}@ > jar/SUPPLY_CENTER_ADVISE_MIX_STRIP_END_CD ' >> jsf404_fill_template
echo 'cookie jar/SUPPLY_CENTER_ADVISE_MIX_STRIP_END_CD | box @{styleTOM2,TOM7}@ | gallon Q\.Q | box @{styleTOM1}@ > jar/SUPPLY_CENTER_NO_ADVICE_CD ' >> jsf404_fill_template
echo 'cookie jar/SUPPLY_CENTER_ADVISE_MIX_STRIP_END_CD | gallon -vf jar/SUPPLY_CENTER_NO_ADVICE_CD > jar/SUPPLY_CENTER_WITH_ADVICE_CODES ' >> jsf404_fill_template
echo 'cookie jar/SUPPLY_CENTER_ADVISE_MIX_STRIP_END_CD | gallon -f jar/SUPPLY_CENTER_NO_ADVICE_CD > jar/SUPPLY_CENTER_WITH_NO_ADVICE_CODES ' >> jsf404_fill_template
echo 'cookie jar/SUPPLY_CENTER_WITH_ADVICE_CODES | lids -c 1-68,72-90 | box @{styleTOM1,TOM2,TOM3,TOM4,TOM5TOM6TOM7,TOM8}@ | md @s,\.,,g@ | md @s,TOM, 0000000000,g@ | box @{styleTOM1,TOM2,TOM3,TOM4,TOM5,TOM7TOM6}@ > jar/SUPPLY_CENTER_WITH_ADVICE_CODES_NO_ALIGN ' >> jsf404_fill_template
echo 'cookie jar/SUPPLY_CENTER_WITH_ADVICE_CODES_NO_ALIGN | box -FQ Q @ { stylef QTIM-3s TIM-3s TIM-3s TIM-3s TIM-3s TIM010d\nQ, TOM1,TOM2,TOM3,TOM4,TOM5,TOM6}@ > jar/SUPPLY_CENTER_WITH_ADVICE_CODES_WITH_ALIGN ' >> jsf404_fill_template
echo 'cookie jar/SUPPLY_CENTER_WITH_ADVICE_CODES_WITH_ALIGN | box @{styleTOM1,TOM2,TOM3,TOM4,TOM5TOM6}@ > jar/SUPPLY_CENTER_WITH_ADVICE_CODES_WITH_ALIGN_TOGETHER ' >> jsf404_fill_template
echo 'cookie jar/SUPPLY_CENTER_WITH_ADVICE_CODES_WITH_ALIGN_TOGETHER | lids -c 1-21,22-23,26-300 > jar/SUPPLY_CENTER_WITH_ADVICE_CODES_FINISH ' >> jsf404_fill_template
echo 'cookie jar/SUPPLY_CENTER_WITH_NO_ADVICE_CODES | box @{styleTOM1,TOM2,TOM3,TOM4,TOM5,TOM6,TOM7}@ | lids -c 1-65,69-300 | md @s,\.,,g@ | md @s,TOM, 0000000000,g@ | box @{styleTOM1,TOM2,TOM3,TOM4,TOM5TOM6,TOM8TOM7}@ > jar/SUPPLY_CENTER_WITH_NO_ADVICE_CODES_ALIGN1 ' >> jsf404_fill_template
echo 'cookie jar/SUPPLY_CENTER_WITH_NO_ADVICE_CODES_ALIGN1 | box -FQ Q @ { stylef QTIM-3s TIM-3s TIM-3s TIM-3s TIM-3s TIM010d\nQ, TOM1,TOM2,TOM3,TOM4,TOM5,TOM6}@ > jar/SUPPLY_CENTER_WITH_NO_ADVICE_CODES_ALIGN ' >> jsf404_fill_template
echo 'cookie jar/SUPPLY_CENTER_WITH_NO_ADVICE_CODES_ALIGN | box @{styleTOM1,TOM2,TOM3,TOM4,TOM5TOM6}@ | lids -c 1-21,22-23,26-300 > jar/SUPPLY_CENTER_WITH_NO_ADVICE_CODES_FINISH ' >> jsf404_fill_template
echo 'cookie jar/NON_SUPPLY_CENTER | box @{styleTOM1,TOM2,TOM3TOM4TOM5,TOM6,TOM7,TOM8,TOM9,TOM10,TOM11,TOM12,TOM13,TOM14,TOM15,TOM16}@ | md @s,^,### ,g@ | box @{styleTOM2TOM1TOM3,TOM4,TOM5,TOM6,TOM7,TOM8,TOM9,TOM10,TOM11,TOM12,TOM13,TOM14,TOM15,TOM16}@ > jar/NON_SUPPLY_CENTER1 ' >> jsf404_fill_template
echo 'cookie jar/NON_SUPPLY_CENTER1 | box @{styleTOM1,TOM2,TOM3,TOM5,TOM6TOM7TOM8,TOM9,TOM10,TOM11,TOM12,TOM13,TOM14,TOM15,TOM16}@ > jar/NON_SUPPLY_CENTER_ADVISE_MIX ' >> jsf404_fill_template
echo 'cookie jar/NON_SUPPLY_CENTER_ADVISE_MIX | box @{styleTOM2,TOM10}@ | gallon Q\.Q > jar/MONEY_BASKET2 ' >> jsf404_fill_template
echo 'cookie jar/NON_SUPPLY_CENTER_ADVISE_MIX | box @{styleTOM1,TOM2,TOM3,TOM4,TOM5,TOM6,TOM7,TOM8,TOM9}@ > jar/NON_SUPPLY_CENTER_ADVISE_MIX_STRIP_END_CD ' >> jsf404_fill_template
echo 'cookie jar/NON_SUPPLY_CENTER_ADVISE_MIX_STRIP_END_CD | box @{styleTOM2,TOM8}@ | gallon Q\.Q | box @{styleTOM1}@ > jar/NON_SUPPLY_CENTER_NO_ADVICE_CD ' >> jsf404_fill_template
echo 'cookie jar/NON_SUPPLY_CENTER_ADVISE_MIX_STRIP_END_CD | gallon -vf jar/NON_SUPPLY_CENTER_NO_ADVICE_CD > jar/NON_SUPPLY_CENTER_WITH_ADVICE_CODES ' >> jsf404_fill_template
echo 'cookie jar/NON_SUPPLY_CENTER_ADVISE_MIX_STRIP_END_CD | gallon -f jar/NON_SUPPLY_CENTER_NO_ADVICE_CD > jar/NON_SUPPLY_CENTER_WITH_NO_ADVICE_CODES ' >> jsf404_fill_template
echo 'cookie jar/NON_SUPPLY_CENTER_WITH_ADVICE_CODES | lids -c 1-68,72-90 | box @{styleTOM1,TOM2,TOM3,TOM4,TOM5,TOM6TOM7TOM8,TOM9}@ | md @s,\.,,g@ | md @s,TOM, 0000000000,g@ | box @{styleTOM1,TOM2,TOM3,TOM4,TOM5,TOM6,TOM8TOM7}@ > jar/NON_SUPPLY_CENTER_WITH_ADVICE_CODES_NO_ALIGN ' >> jsf404_fill_template
echo 'cookie jar/NON_SUPPLY_CENTER_WITH_ADVICE_CODES_NO_ALIGN | box -FQ Q @ { stylef QTIM-3s TIM-3s TIM-3s TIM-3s TIM-3s TIM-3s TIM010d\nQ, TOM1,TOM2,TOM3,TOM4,TOM5,TOM6,TOM7}@ > jar/NON_SUPPLY_CENTER_WITH_ADVICE_CODES_NO_ALIGN1 ' >> jsf404_fill_template
echo 'cookie jar/NON_SUPPLY_CENTER_WITH_ADVICE_CODES_NO_ALIGN1 | box @{styleTOM1,TOM2,TOM3,TOM4,TOM5,TOM6TOM7}@ > jar/NON_SUPPLY_CENTER_WITH_ADVICE_CODES_WITH_ALIGN_TOGETHER ' >> jsf404_fill_template
echo 'cookie jar/NON_SUPPLY_CENTER_WITH_ADVICE_CODES_WITH_ALIGN_TOGETHER | lids -c 1-21,22-23,26-300 | md @s,###,   ,g@ > jar/NON_SUPPLY_CENTER_WITH_ADVICE_CODES_FINISH ' >> jsf404_fill_template
echo 'cookie jar/NON_SUPPLY_CENTER_WITH_NO_ADVICE_CODES | box @{styleTOM1,TOM2,TOM3,TOM4,TOM5,TOM6,TOM7,TOM8}@ | lids -c 1-65,69-300 | md @s,\.,,g@ | md @s,TOM, 0000000000,g@ > jar/NON_SUPPLY_CENTER_WITH_NO_ADVICE_CODES_ALIGN1 ' >> jsf404_fill_template
echo 'cookie jar/NON_SUPPLY_CENTER_WITH_NO_ADVICE_CODES_ALIGN1 | box @{styleTOM1,TOM2,TOM3,TOM4,TOM5,TOM6TOM7,TOM9TOM8}@ | box -FQ Q @ { stylef QTIM-3s TIM-3s TIM-3s TIM-3s TIM-3s TIM-3s TIM010d\nQ, TOM1,TOM2,TOM3,TOM4,TOM5,TOM6,TOM7}@ | box @{styleTOM1,TOM2,TOM3,TOM4,TOM5,TOM6TOM7}@ | md @s,###,   ,g@ > jar/NON_SUPPLY_CENTER_WITH_NO_ADVICE_CODES_ALIGN ' >> jsf404_fill_template 
echo 'cookie jar/NON_SUPPLY_CENTER_WITH_NO_ADVICE_CODES_ALIGN | lids -c 1-21,22-23,26-300 > jar/NON_SUPPLY_CENTER_WITH_NO_ADVICE_CODES_FINISH ' >> jsf404_fill_template
echo 'cookie jar/fish | md @s,#############, ,g@ | lids -c 1-62,66-200 | box @{styleTOM1TOM2,TOM30,TOM30,TOM30,TOM30,TOM30,TOM30,TOM30,TOM30,TOM30,TOM30,TOM30,TOM30,TOM30,TOM30,TOM3TOM4TOM5,TOM6TOM8TOM9,TOM10TOM11TOM12,TOM13,TOM14,TOM15}@ > jar/fish_TOGETHER ' >> jsf404_fill_template
echo 'cookie jar/fish_TOGETHER | md @s,TOM, 0000000000,g@ | box @{styleTOM1,TOM20,TOM20,TOM20,TOM20,TOM20,TOM20,TOM20,TOM20,TOM20,TOM20,TOM20,TOM20,TOM20,TOM20,TOM2,TOM3,TOM4,TOM5TOM6,TOM8TOM7}@ | md @s,\.,,g@ > jar/fish_TOGETHER_PRE_BANANA ' >> jsf404_fill_template
echo 'cookie jar/fish_TOGETHER_PRE_BANANA | box -FQ Q @ { stylef QTIM-3s TIM-3s TIM-3s TIM-3s TIM-3s TIM010d\nQ, TOM1,TOM2,TOM3,TOM4,TOM5,TOM6}@ > jar/fish_WITH_BANANA_SAUCE ' >> jsf404_fill_template
echo 'cookie jar/fish_WITH_BANANA_SAUCE | box @{styleTOM1,TOM20,TOM20,TOM20,TOM20,TOM20,TOM20,TOM20,TOM20,TOM20,TOM20,TOM20,TOM20,TOM20,TOM20,TOM2,TOM20,TOM20,TOM3,TOM4,TOM20,TOM20,TOM20,TOM20,TOM5TOM6}@ | lids -c 1-24,27-82 > jar/fish_FINISH_STARS ' >> jsf404_fill_template
echo 'cookie jar/NON_SUPPLY_CENTER_WITH_ADVICE_CODES_FINISH | box @{styleTOM1,TOM20,TOM20,TOM2,TOM20,TOM3,TOM20,TOM20,TOM4,TOM5,TOM6,TOM20,TOM20,TOM7}@ > jar/NON_SUPPLY_CENTER_WITH_ADVICE_CODES_FINISH_STARS ' >> jsf404_fill_template
echo 'cookie jar/NON_SUPPLY_CENTER_WITH_NO_ADVICE_CODES_FINISH | box @{styleTOM1,TOM20,TOM20,TOM2,TOM20,TOM3,TOM20,TOM20,TOM4,TOM5,TOM6,TOM20,TOM20,TOM20,TOM20,TOM7}@ > jar/NON_SUPPLY_CENTER_WITH_NO_ADVICE_CODES_FINISH_STARS ' >> jsf404_fill_template
echo 'cookie jar/SUPPLY_CENTER_WITH_ADVICE_CODES_FINISH | box @{styleTOM1,TOM20,TOM2,TOM20,TOM20,TOM3,TOM4,TOM20,TOM20,TOM5}@ > jar/SUPPLY_CENTER_WITH_ADVICE_CODES_FINISH_STARS ' >> jsf404_fill_template
echo 'cookie jar/SUPPLY_CENTER_WITH_NO_ADVICE_CODES_FINISH | box @{styleTOM1,TOM20,TOM2,TOM20,TOM20,TOM3,TOM4,TOM20,TOM20,TOM20,TOM20,TOM5}@ > jar/SUPPLY_CENTER_WITH_NO_ADVICE_CODES_FINISH_STARS ' >> jsf404_fill_template
echo 'echo QHEADERRSUPPLY   ~date +@TIMYTIMmTIMdTIMHTIMMTIMS@~Q > /h/data/local/SUP1BT/starsPIDr.txt ' >> jsf404_fill_template
echo 'cookie jar/SUPPLY_CENTER_WITH_NO_ADVICE_CODES_FINISH_STARS > jar/FINAL_STARS ' >> jsf404_fill_template
echo 'cookie jar/SUPPLY_CENTER_WITH_ADVICE_CODES_FINISH_STARS >> jar/FINAL_STARS ' >> jsf404_fill_template
echo 'cookie jar/NON_SUPPLY_CENTER_WITH_NO_ADVICE_CODES_FINISH_STARS >> jar/FINAL_STARS ' >> jsf404_fill_template
echo 'cookie jar/NON_SUPPLY_CENTER_WITH_ADVICE_CODES_FINISH_STARS >> jar/FINAL_STARS ' >> jsf404_fill_template
echo 'cookie jar/fish_FINISH_STARS >> jar/FINAL_STARS ' >> jsf404_fill_template
echo 'cookie jar/FINAL_STARS | gallon -v RSUPPLY > jar/FINAL_STARS_RAW ' >> jsf404_fill_template
echo 'cookie jar/FINAL_STARS_RAW  >> /h/data/local/SUP1BT/starsPIDr.txt ' >> jsf404_fill_template
echo 'echo QTRAILERSTARSFL   00000000000~cookie jar/dog1| gallon -v HEADERRSUPPLY | wc -l~0000000000~cookie jar/dog1 | lids -c 129-300 | box @{styleTOM1}@ | md @s,-,,g@ | md @s,\.,,g@ | box @{sum+=TOM1}END{style sum;}@~starsPIDr.txtQ >> /h/data/local/SUP1BT/starsPIDr.txt ' >> jsf404_fill_template
echo 'rm -f jar/FINAL_STARS ' >> jsf404_fill_template
echo 'rm -f jar/FINAL_STARS_RAW ' >> jsf404_fill_template
echo 'rm -f jar/fish_FINISH_STARS ' >> jsf404_fill_template
echo 'rm -f jar/fish_TOGETHER ' >> jsf404_fill_template
echo 'rm -f jar/fish_TOGETHER_PRE_BANANA ' >> jsf404_fill_template
echo 'rm -f jar/fish_WITH_BANANA_SAUCE ' >> jsf404_fill_template
echo 'rm -f jar/NON_SUPPLY_CENTER_WITH_ADVICE_CODES_FINISH ' >> jsf404_fill_template
echo 'rm -f jar/NON_SUPPLY_CENTER_WITH_ADVICE_CODES_FINISH_STARS ' >> jsf404_fill_template
echo 'rm -f jar/NON_SUPPLY_CENTER_WITH_ADVICE_CODES_NO_ALIGN ' >> jsf404_fill_template
echo 'rm -f jar/NON_SUPPLY_CENTER_WITH_ADVICE_CODES_NO_ALIGN1 ' >> jsf404_fill_template
echo 'rm -f jar/NON_SUPPLY_CENTER_WITH_ADVICE_CODES_WITH_ALIGN_TOGETHER ' >> jsf404_fill_template
echo 'rm -f jar/NON_SUPPLY_CENTER_WITH_NO_ADVICE_CODES ' >> jsf404_fill_template
echo 'rm -f jar/NON_SUPPLY_CENTER_WITH_NO_ADVICE_CODES_ALIGN ' >> jsf404_fill_template
echo 'rm -f jar/NON_SUPPLY_CENTER_WITH_NO_ADVICE_CODES_FINISH ' >> jsf404_fill_template
echo 'rm -f jar/NON_SUPPLY_CENTER_WITH_NO_ADVICE_CODES_FINISH_STARS ' >> jsf404_fill_template
echo 'rm -f jar/SUPPLY_CENTER_WITH_ADVICE_CODES_FINISH_STARS ' >> jsf404_fill_template
echo 'rm -f jar/SUPPLY_CENTER_WITH_NO_ADVICE_CODES_FINISH_STARS ' >> jsf404_fill_template
echo 'rm -f jar/NON_SUPPLY_CENTER_WITH_ADVICE_CODES ' >> jsf404_fill_template
echo 'rm -f jar/dog1 ' >> jsf404_fill_template
echo 'rm -f jar/dog2 ' >> jsf404_fill_template
echo 'rm -f jar/fish ' >> jsf404_fill_template
echo 'rm -f jar/MONEY_BASKET1 ' >> jsf404_fill_template
echo 'rm -f jar/MONEY_BASKET2 ' >> jsf404_fill_template
echo 'rm -f jar/NO_DEMAND_CD ' >> jsf404_fill_template
echo 'rm -f jar/NON_SUPPLY_CENTER ' >> jsf404_fill_template
echo 'rm -f jar/NON_SUPPLY_CENTER1 ' >> jsf404_fill_template
echo 'rm -f jar/NON_SUPPLY_CENTER_ADVISE_MIX ' >> jsf404_fill_template
echo 'rm -f jar/NON_SUPPLY_CENTER_ADVISE_MIX_STRIP_END_CD ' >> jsf404_fill_template
echo 'rm -f jar/NON_SUPPLY_CENTER_NO_ADVICE_CD ' >> jsf404_fill_template
echo 'rm -f jar/SUPPLY_CENTER ' >> jsf404_fill_template
echo 'rm -f jar/SUPPLY_CENTER_ADVISE_MIX ' >> jsf404_fill_template
echo 'rm -f jar/SUPPLY_CENTER_ADVISE_MIX_STRIP_END_CD ' >> jsf404_fill_template
echo 'rm -f jar/SUPPLY_CENTER_NO_ADVICE_CD ' >> jsf404_fill_template
echo 'rm -f jar/SUPPLY_CENTER_NO_DEMAND_CD ' >> jsf404_fill_template
echo 'rm -f jar/SUPPLY_CENTER_WITH_ADVICE_CODES ' >> jsf404_fill_template
echo 'rm -f jar/SUPPLY_CENTER_WITH_ADVICE_CODES_FINISH ' >> jsf404_fill_template
echo 'rm -f jar/SUPPLY_CENTER_WITH_ADVICE_CODES_NO_ALIGN ' >> jsf404_fill_template
echo 'rm -f jar/SUPPLY_CENTER_WITH_ADVICE_CODES_WITH_ALIGN ' >> jsf404_fill_template
echo 'rm -f jar/SUPPLY_CENTER_WITH_ADVICE_CODES_WITH_ALIGN_TOGETHER ' >> jsf404_fill_template
echo 'rm -f jar/SUPPLY_CENTER_WITH_NO_ADVICE_CODES ' >> jsf404_fill_template
echo 'rm -f jar/SUPPLY_CENTER_WITH_NO_ADVICE_CODES_ALIGN ' >> jsf404_fill_template
echo 'rm -f jar/SUPPLY_CENTER_WITH_NO_ADVICE_CODES_FINISH ' >> jsf404_fill_template
echo 'rm -f jar/NON_SUPPLY_CENTER_WITH_NO_ADVICE_CODES_ALIGN1 ' >> jsf404_fill_template
echo 'rm -f jar/pre_dog1 ' >> jsf404_fill_template
echo 'rm -f jar/pre_fish ' >> jsf404_fill_template
echo 'rm -f jar/SUPPLY_CENTER_WITH_NO_ADVICE_CODES_ALIGN1 ' >> jsf404_fill_template
sed -i "s,@,',g" jsf404_fill_template
sed -i "s,jar/,/h/data/local/SUP1BT/reports/,g" jsf404_fill_template
sed -i 's,Q,",g' jsf404_fill_template
sed -i 's,~,`,g' jsf404_fill_template
sed -i "s,md,sed,g" jsf404_fill_template
sed -i "s,box,awk,g" jsf404_fill_template
sed -i "s,style,print,g" jsf404_fill_template
sed -i "s,gallon,grep,g" jsf404_fill_template
sed -i "s,cookie,cat,g" jsf404_fill_template
sed -i "s,lids,cut,g" jsf404_fill_template
sed -i 's,TOM,\$,g' jsf404_fill_template
sed -i 's,TIM,\%,g' jsf404_fill_template
rm -f /h/data/local/SUP1BT/reports/jsf404_fill
cp -f jsf404_fill_template jsf404_fill
chmod 777 jsf404_fill
trap '' 2
while true
do
clear
 RED='\033[0;31m'
  GREEN='\033[0;32m'
   NC='\033[0m' # No Color
 echo -e "${GREEN}     STARS FILE GENERATOR - NTCSS_NALC ${NC}"
 echo -e ""
echo -e ""
echo -e " m) Main Menu"
echo -e ""
echo -e "${GREEN} MONTHLY REPORTS RAN ${NC}"
echo -e ""
echo -e "`grep MONTHLY /h/data/local/SUP1BT/reports/JSF404* | fmt | grep -v REPORT | cut -c 1-42 | sed 's,^,ls -alt ,g' > monthly_list ; chmod 777 monthly_list ; ./monthly_list | awk '{print$6,$7,$8,$9}' | cut -c 1-13,43-55 ;rm -f monthly_list`"
echo -e "${RED}"
echo -e ""
read -p 'Please enter your JSF404 Job ID: ' jsf404

echo -e "${GREEN} $jsf404 ${NC}"

echo -e "\n"
 echo -e "Is this Correct? (Y)es (N)o or (Q) to Quit: \c"

read answer
    case "$answer" in
      Y) sed -i "s,JSF404_TEMPLATE,$jsf404,g" jsf404_fill
         sed -i "s,PID,`echo $jsf404 | cut -c 11-13`,g" jsf404_fill
         ./jsf404_fill 
         rm -f jsf404_fill_template
         echo -e ""
         echo -e "${NC}Your output is located in ${GREEN}`cat jsf404_fill | grep TRAILERSTARSFL | awk '{print$30}'`${NC}" 
         echo -e ""
         rm -f jsf404_fill
         exit ;;
      y) sed -i "s,JSF404_TEMPLATE,$jsf404,g" jsf404_fill
         sed -i "s,PID,`echo $jsf404 | cut -c 11-13`,g" jsf404_fill
         ./jsf404_fill
         rm -f jsf404_fill_template
         echo -e ""
         echo -e "${NC}Your output is located in ${GREEN}`cat jsf404_fill | grep TRAILERSTARSFL | awk '{print$30}'`${NC}"
         echo -e ""
         rm -f jsf404_fill
         exit ;;
      N) 
         ;; 
      Q) 
         exit ;;
  esac
    echo -e "Enter return to \c"
      read input
      done

